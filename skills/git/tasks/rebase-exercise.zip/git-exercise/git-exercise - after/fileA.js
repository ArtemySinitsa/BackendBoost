console.log({
  propA: 42,
  propB: 'string',
  propC: new Date(),
});
