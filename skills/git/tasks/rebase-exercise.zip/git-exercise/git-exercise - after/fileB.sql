SELECT *
FROM my_table
WHERE status != 'deleted'
